package com.example.geokit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.net.PlacesClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationClient;
    private PlacesClient placesClient;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    private static final int MARKER_LIST_REQUEST_CODE = 2;

    // UI 요소들
    private EditText editSearch;
    private ImageButton btnMenu;

    // 저장된 마커들 리스트 (하늘색 마커만)
    private List<Marker> savedMarkers = new ArrayList<>();

    // 검색 결과 임시 마커 (초록색 마커)
    private Marker searchResultMarker = null;

    // SharedPreferences for 영구 저장
    private SharedPreferences sharedPreferences;
    private static final String PREFS_NAME = "GeoKitPrefs";
    private static final String MARKERS_KEY = "saved_markers";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // SharedPreferences 초기화
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Places API 초기화
        Places.initialize(getApplicationContext(), "AIzaSyOyE1u45gaVOizEpn8aLRu2fzcFXyVMe_0");
        placesClient = Places.createClient(this);

        // Location client 초기화
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // UI 요소들 초기화
        initViews();

        // Map fragment 얻기
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        // + 버튼 클릭 리스너
        FloatingActionButton fabAddMarker = findViewById(R.id.fab_add_marker);
        fabAddMarker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addCurrentLocationMarker();
            }
        });
    }

    private void initViews() {
        editSearch = findViewById(R.id.edit_search);
        btnMenu = findViewById(R.id.btn_menu);

        // 검색창 설정 (Google 어시스턴트 바만 방지)
        editSearch.setInputType(android.text.InputType.TYPE_CLASS_TEXT);
        editSearch.setPrivateImeOptions("nm");

        // 검색창 포커스 리스너 추가
        editSearch.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    android.view.inputmethod.InputMethodManager imm =
                            (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    imm.showSoftInput(editSearch, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);

                    if (searchResultMarker != null) {
                        searchResultMarker.remove();
                        searchResultMarker = null;
                    }
                }
            }
        });

        // 검색창 클릭 리스너 추가 (추가 보장)
        editSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editSearch.requestFocus();
                android.view.inputmethod.InputMethodManager imm =
                        (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                imm.showSoftInput(editSearch, android.view.inputmethod.InputMethodManager.SHOW_FORCED);
            }
        });

        // 검색창 엔터키 리스너
        editSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                        (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    performSearch();
                    return true;
                }
                return false;
            }
        });

        // 메뉴 버튼 클릭 리스너 - 새 액티비티 열기
        btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMarkerListActivity();
            }
        });
    }

    // 마커 저장
    private void saveMarkersToPreferences() {
        JSONArray markersArray = new JSONArray();

        for (Marker marker : savedMarkers) {
            try {
                JSONObject markerObj = new JSONObject();
                markerObj.put("title", marker.getTitle());
                markerObj.put("latitude", marker.getPosition().latitude);
                markerObj.put("longitude", marker.getPosition().longitude);
                markersArray.put(markerObj);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(MARKERS_KEY, markersArray.toString());
        editor.apply();
    }

    // 마커 로드
    private void loadSavedMarkers() {
        String markersJson = sharedPreferences.getString(MARKERS_KEY, "[]");

        try {
            JSONArray markersArray = new JSONArray(markersJson);

            for (int i = 0; i < markersArray.length(); i++) {
                JSONObject markerObj = markersArray.getJSONObject(i);

                String title = markerObj.getString("title");
                double latitude = markerObj.getDouble("latitude");
                double longitude = markerObj.getDouble("longitude");

                LatLng position = new LatLng(latitude, longitude);

                Marker marker = mMap.addMarker(new MarkerOptions()
                        .position(position)
                        .title(title)
                        .icon(createCustomMarkerIcon()));

                if (marker != null) {
                    savedMarkers.add(marker);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void openMarkerListActivity() {
        Intent intent = new Intent(this, MarkerListActivity.class);

        // 마커 데이터를 Intent로 전달
        ArrayList<String> markerNames = new ArrayList<>();
        ArrayList<Double> markerLats = new ArrayList<>();
        ArrayList<Double> markerLngs = new ArrayList<>();

        for (Marker marker : savedMarkers) {
            markerNames.add(marker.getTitle());
            markerLats.add(marker.getPosition().latitude);
            markerLngs.add(marker.getPosition().longitude);
        }

        intent.putStringArrayListExtra("marker_names", markerNames);
        intent.putExtra("marker_lats", markerLats);
        intent.putExtra("marker_lngs", markerLngs);
        intent.putExtra("total_count", savedMarkers.size());

        startActivityForResult(intent, MARKER_LIST_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == MARKER_LIST_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            // 지도에서 보기 요청
            if (data.hasExtra("goto_latitude")) {
                double lat = data.getDoubleExtra("goto_latitude", 0);
                double lng = data.getDoubleExtra("goto_longitude", 0);
                String name = data.getStringExtra("goto_name");

                LatLng location = new LatLng(lat, lng);
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(location, 15));

                // 해당 마커 찾아서 정보창 표시
                for (Marker marker : savedMarkers) {
                    if (Math.abs(marker.getPosition().latitude - lat) < 0.0001 &&
                            Math.abs(marker.getPosition().longitude - lng) < 0.0001) {
                        marker.showInfoWindow();
                        break;
                    }
                }

                Toast.makeText(this, name + "로 이동했습니다", Toast.LENGTH_SHORT).show();
            }

            // 마커 삭제 요청
            if (data.hasExtra("delete_marker_name")) {
                String nameToDelete = data.getStringExtra("delete_marker_name");
                double latToDelete = data.getDoubleExtra("delete_marker_lat", 0);
                double lngToDelete = data.getDoubleExtra("delete_marker_lng", 0);

                // 마커 찾아서 삭제
                Iterator<Marker> iterator = savedMarkers.iterator();
                while (iterator.hasNext()) {
                    Marker marker = iterator.next();
                    if (Math.abs(marker.getPosition().latitude - latToDelete) < 0.0001 &&
                            Math.abs(marker.getPosition().longitude - lngToDelete) < 0.0001) {
                        marker.remove();
                        iterator.remove();

                        // 마커 삭제 후 저장
                        saveMarkersToPreferences();

                        Toast.makeText(this, nameToDelete + " 마커가 삭제되었습니다", Toast.LENGTH_SHORT).show();
                        break;
                    }
                }
            }
        }
    }

    private void performSearch() {
        String query = editSearch.getText().toString().trim();
        if (query.isEmpty()) {
            Toast.makeText(this, "검색어를 입력해주세요", Toast.LENGTH_SHORT).show();
            return;
        }

        // 키보드 숨기기
        android.view.inputmethod.InputMethodManager imm =
                (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(editSearch.getWindowToken(), 0);

        // 먼저 저장된 마커에서 검색
        if (searchInSavedMarkers(query)) {
            return; // 저장된 마커에서 찾았으면 종료
        }

        // Google Places API로 검색
        searchWithPlacesAPI(query);
    }

    private boolean searchInSavedMarkers(String query) {
        for (Marker marker : savedMarkers) {
            if (marker.getTitle() != null &&
                    marker.getTitle().toLowerCase().contains(query.toLowerCase())) {

                // 찾은 마커로 이동
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(marker.getPosition(), 15));
                marker.showInfoWindow();

                Toast.makeText(this, "저장된 장소 '" + marker.getTitle() + "'을 찾았습니다",
                        Toast.LENGTH_SHORT).show();
                return true;
            }
        }
        return false;
    }

    private void searchWithPlacesAPI(String query) {
        // 이전 검색 결과 마커가 있다면 제거
        if (searchResultMarker != null) {
            searchResultMarker.remove();
            searchResultMarker = null;
        }

        android.location.Geocoder geocoder = new android.location.Geocoder(this);

        try {
            List<android.location.Address> addresses = geocoder.getFromLocationName(query, 1);
            if (addresses != null && !addresses.isEmpty()) {
                android.location.Address address = addresses.get(0);
                LatLng location = new LatLng(address.getLatitude(), address.getLongitude());

                // 검색 결과 위치로 이동
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(location, 15));

                // 임시 마커 추가 (저장되지 않는 검색 결과용)
                searchResultMarker = mMap.addMarker(new MarkerOptions()
                        .position(location)
                        .title("검색 결과: " + query)
                        .snippet("+ 버튼을 눌러서 저장할 수 있어요")
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));

                // 정보창 자동으로 열기
                if (searchResultMarker != null) {
                    searchResultMarker.showInfoWindow();
                }

                Toast.makeText(this, "'" + query + "' 검색 완료", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "검색 결과를 찾을 수 없습니다", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "검색 중 오류가 발생했습니다", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // 커스텀 정보창 어댑터 설정
        mMap.setInfoWindowAdapter(new CustomInfoWindowAdapter());

        // 지도 클릭 리스너 추가 (검색 결과 마커 제거용)
        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                if (searchResultMarker != null) {
                    searchResultMarker.remove();
                    searchResultMarker = null;
                }
            }
        });

        // 위치 권한 확인 및 요청
        enableMyLocation();

        // 저장된 마커들 로드
        loadSavedMarkers();
    }

    // 커스텀 정보창 어댑터 클래스
    private class CustomInfoWindowAdapter implements GoogleMap.InfoWindowAdapter {
        @Override
        public View getInfoWindow(Marker marker) {
            View view = getLayoutInflater().inflate(R.layout.custom_info_window, null);

            TextView tvPlaceName = view.findViewById(R.id.tv_place_name);
            TextView tvLocationInfo = view.findViewById(R.id.tv_location_info);

            tvPlaceName.setText(marker.getTitle());

            // 검색 결과인지 저장된 마커인지 구분
            if (marker.getTitle() != null && marker.getTitle().startsWith("검색 결과:")) {
                tvLocationInfo.setText("검색 결과 (+ 버튼으로 저장 가능)");
            } else {
                tvLocationInfo.setText("내가 저장한 장소");
            }

            return view;
        }

        @Override
        public View getInfoContents(Marker marker) {
            return null;
        }
    }

    private void enableMyLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            mMap.setMyLocationEnabled(true);
            moveToCurrentLocation();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        }
    }

    private void moveToCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, new com.google.android.gms.tasks.OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        if (location != null) {
                            LatLng currentLocation = new LatLng(location.getLatitude(), location.getLongitude());
                            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLocation, 15));
                        } else {
                            LatLng seoul = new LatLng(37.5665, 126.9780);
                            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(seoul, 10));
                        }
                    }
                });
    }

    private void addCurrentLocationMarker() {
        // 검색 결과 마커가 있으면 제거
        if (searchResultMarker != null) {
            searchResultMarker.remove();
            searchResultMarker = null;
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "위치 권한이 필요합니다", Toast.LENGTH_SHORT).show();
            return;
        }

        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, new com.google.android.gms.tasks.OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        if (location != null) {
                            LatLng currentLocation = new LatLng(location.getLatitude(), location.getLongitude());
                            showAddMarkerDialog(currentLocation);
                        } else {
                            Toast.makeText(MainActivity.this, "현재 위치를 찾을 수 없습니다", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void showAddMarkerDialog(LatLng location) {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);

        android.view.LayoutInflater inflater = getLayoutInflater();
        android.view.View dialogView = inflater.inflate(R.layout.dialog_add_marker, null);
        builder.setView(dialogView);

        com.google.android.material.textfield.TextInputEditText editPlaceName =
                dialogView.findViewById(R.id.edit_place_name);
        com.google.android.material.button.MaterialButton btnAdd =
                dialogView.findViewById(R.id.btn_add);
        com.google.android.material.button.MaterialButton btnCancel =
                dialogView.findViewById(R.id.btn_cancel);

        android.app.AlertDialog dialog = builder.create();
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String placeName = editPlaceName.getText().toString().trim();
                if (!placeName.isEmpty()) {

                    BitmapDescriptor customIcon = createCustomMarkerIcon();

                    // 마커 추가하고 저장된 마커 리스트에만 추가 (하늘색 마커만)
                    Marker newMarker = mMap.addMarker(new MarkerOptions()
                            .position(location)
                            .title(placeName)
                            .icon(customIcon));

                    // 저장된 마커 리스트에 추가
                    if (newMarker != null) {
                        savedMarkers.add(newMarker);
                        // 마커 추가 후 저장
                        saveMarkersToPreferences();
                    }

                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(location, 15));

                    Toast.makeText(MainActivity.this, "'" + placeName + "' 마커가 추가되었습니다", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                } else {
                    Toast.makeText(MainActivity.this, "장소 이름을 입력해주세요", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private BitmapDescriptor createCustomMarkerIcon() {
        return BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_CYAN);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enableMyLocation();
            } else {
                Toast.makeText(this, "위치 권한이 거부되었습니다", Toast.LENGTH_SHORT).show();
                LatLng seoul = new LatLng(37.5665, 126.9780);
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(seoul, 10));
            }
        }
    }
}