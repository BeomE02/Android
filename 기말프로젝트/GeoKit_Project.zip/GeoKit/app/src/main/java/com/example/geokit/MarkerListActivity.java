package com.example.geokit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class MarkerListActivity extends AppCompatActivity {

    private RecyclerView recyclerMarkersDetailList;
    private EditText editSearchList;
    private TextView tvTotalCount, tvThisMonth, tvThisWeek;

    private MarkerDetailListAdapter adapter;
    private List<MarkerData> markerDataList = new ArrayList<>();
    private List<MarkerData> filteredList = new ArrayList<>();

    // 마커 데이터 클래스
    public static class MarkerData {
        public String name;
        public double latitude;
        public double longitude;
        public String dateAdded;

        public MarkerData(String name, double latitude, double longitude, String dateAdded) {
            this.name = name;
            this.latitude = latitude;
            this.longitude = longitude;
            this.dateAdded = dateAdded;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_marker_list);

        initViews();
        loadMarkerData();
        setupRecyclerView();
        updateStatistics();
    }

    private void initViews() {
        recyclerMarkersDetailList = findViewById(R.id.recycler_markers_list);
        editSearchList = findViewById(R.id.edit_search_list);
        tvTotalCount = findViewById(R.id.tv_total_count);
        tvThisMonth = findViewById(R.id.tv_this_month);
        tvThisWeek = findViewById(R.id.tv_this_week);

        // 검색 기능
        editSearchList.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterMarkers(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void loadMarkerData() {
        // MainActivity에서 전달받은 마커 데이터 로드
        ArrayList<String> markerNames = getIntent().getStringArrayListExtra("marker_names");
        ArrayList<Double> markerLats = (ArrayList<Double>) getIntent().getSerializableExtra("marker_lats");
        ArrayList<Double> markerLngs = (ArrayList<Double>) getIntent().getSerializableExtra("marker_lngs");

        if (markerNames != null && markerLats != null && markerLngs != null) {
            for (int i = 0; i < markerNames.size(); i++) {
                String currentDate = new SimpleDateFormat("yyyy.MM.dd", Locale.getDefault()).format(new Date());
                markerDataList.add(new MarkerData(
                        markerNames.get(i),
                        markerLats.get(i),
                        markerLngs.get(i),
                        currentDate
                ));
            }
        }

        filteredList.addAll(markerDataList);
    }

    private void setupRecyclerView() {
        adapter = new MarkerDetailListAdapter();
        recyclerMarkersDetailList.setLayoutManager(new LinearLayoutManager(this));
        recyclerMarkersDetailList.setAdapter(adapter);
    }

    private void filterMarkers(String query) {
        filteredList.clear();
        if (query.isEmpty()) {
            filteredList.addAll(markerDataList);
        } else {
            for (MarkerData marker : markerDataList) {
                if (marker.name.toLowerCase().contains(query.toLowerCase())) {
                    filteredList.add(marker);
                }
            }
        }
        adapter.notifyDataSetChanged();
    }

    private void updateStatistics() {
        int totalCount = markerDataList.size();
        tvTotalCount.setText(String.valueOf(totalCount));

        // 이번 달 계산 (현재는 임시로 전체 개수)
        tvThisMonth.setText(String.valueOf(totalCount));

        // 이번 주 계산 (현재는 임시로 1)
        tvThisWeek.setText("1");
    }

    // 지도 썸네일 생성 (Google Street View Static API 사용)
    private String generateMapThumbnailUrl(double lat, double lng) {
        // Google Static Maps API 사용
        String apiKey = "AIzaSyOyE1u45gaVOizEpn8aLRu2fzcFXyVMe_0";
        return "https://maps.googleapis.com/maps/api/staticmap?" +
                "center=" + lat + "," + lng +
                "&zoom=15" +
                "&size=300x300" +
                "&markers=color:blue%7C" + lat + "," + lng +
                "&key=" + apiKey;
    }

    // 마커 상세 리스트 어댑터
    private class MarkerDetailListAdapter extends RecyclerView.Adapter<MarkerDetailListAdapter.ViewHolder> {

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_marker_detailed, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            MarkerData markerData = filteredList.get(position);
            holder.bind(markerData, position);
        }

        @Override
        public int getItemCount() {
            return filteredList.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvPlaceNameDetailed;
            TextView tvDateAdded;
            ImageView mapThumbnail;
            com.google.android.material.button.MaterialButton btnGoToMap;
            ImageButton btnDeleteDetailed;

            ViewHolder(View itemView) {
                super(itemView);
                tvPlaceNameDetailed = itemView.findViewById(R.id.tv_place_name_detailed);
                tvDateAdded = itemView.findViewById(R.id.tv_date_added);
                mapThumbnail = itemView.findViewById(R.id.map_thumbnail);
                btnGoToMap = itemView.findViewById(R.id.btn_go_to_map);
                btnDeleteDetailed = itemView.findViewById(R.id.btn_delete_detailed);
            }

            void bind(MarkerData markerData, int position) {
                tvPlaceNameDetailed.setText(markerData.name);
                tvDateAdded.setText("저장 일시 | " + markerData.dateAdded);

                // 지도 썸네일 생성 (Google Street View 링크)
                generateMapThumbnail(markerData.latitude, markerData.longitude);

                // 지도에서 보기 버튼
                btnGoToMap.setOnClickListener(v -> {
                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("goto_latitude", markerData.latitude);
                    resultIntent.putExtra("goto_longitude", markerData.longitude);
                    resultIntent.putExtra("goto_name", markerData.name);
                    setResult(RESULT_OK, resultIntent);
                    finish();
                });

                // 삭제 버튼
                btnDeleteDetailed.setOnClickListener(v -> {
                    // 리스트에서 제거
                    markerDataList.remove(markerData);
                    filteredList.remove(markerData);

                    // 어댑터 업데이트
                    notifyItemRemoved(position);
                    notifyItemRangeChanged(position, filteredList.size());

                    // 통계 업데이트
                    updateStatistics();

                    // MainActivity에 삭제 요청 전달
                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("delete_marker_name", markerData.name);
                    resultIntent.putExtra("delete_marker_lat", markerData.latitude);
                    resultIntent.putExtra("delete_marker_lng", markerData.longitude);
                    setResult(RESULT_OK, resultIntent);

                    Toast.makeText(MarkerListActivity.this, markerData.name + " 삭제됨", Toast.LENGTH_SHORT).show();
                });
            }

            private void generateMapThumbnail(double lat, double lng) {
                // 간단한 지도 모양 아이콘 생성
                Bitmap bitmap = Bitmap.createBitmap(80, 80, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(bitmap);

                // 배경
                Paint bgPaint = new Paint();
                bgPaint.setColor(Color.parseColor("#E8F5E8"));
                canvas.drawRect(0, 0, 80, 80, bgPaint);

                // 가로/세로 선 (도로 느낌)
                Paint roadPaint = new Paint();
                roadPaint.setColor(Color.parseColor("#CCCCCC"));
                roadPaint.setStrokeWidth(2);

                // 가로선들
                for (int i = 20; i < 80; i += 20) {
                    canvas.drawLine(0, i, 80, i, roadPaint);
                }

                // 세로선들
                for (int i = 20; i < 80; i += 20) {
                    canvas.drawLine(i, 0, i, 80, roadPaint);
                }

                // 마커 표시
                Paint markerPaint = new Paint();
                markerPaint.setColor(Color.parseColor("#4285F4"));
                canvas.drawCircle(40, 40, 8, markerPaint);

                // 썸네일 설정
                mapThumbnail.setImageBitmap(bitmap);
            }
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}